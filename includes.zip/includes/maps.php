<?php
function generateMapEmbed($address, $city, $apiKey) {
    $location = urlencode("$address, $city");
    return "https://www.google.com/maps/embed/v1/place?key=$apiKey&q=$location";
}
?>